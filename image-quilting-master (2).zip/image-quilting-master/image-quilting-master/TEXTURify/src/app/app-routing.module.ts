import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then(m => m.HomePageModule)
  },
  {
    path: 'list',
    loadChildren: () => import('./list/list.module').then(m => m.ListPageModule)
  },
  {
    path: 'texture-synthesis',
    loadChildren: () => import('./pages/texture-synthesis/texture-synthesis.module').then( m => m.TextureSynthesisPageModule)
  },
  {
    path: 'texture-transfer',
    loadChildren: () => import('./pages/texture-transfer/texture-transfer.module').then( m => m.TextureTransferPageModule)
  },
  {
    path: 'result/:img_path',
    loadChildren: () => import('./pages/result/result.module').then( m => m.ResultPageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
